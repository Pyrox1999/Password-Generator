This app generates you a secure password with letters, digits and symbols. First you must enter the length. Then it generates for you!

Music by Wolfgang_